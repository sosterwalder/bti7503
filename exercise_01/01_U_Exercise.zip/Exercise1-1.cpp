/*
 * Turn all arguments in the following functions (only where it make sense)
 * into reference type arguments:
 *
 */

#include <iostream>

class Huge {
public:
  int key;
  int a[1000];
};

int compareHuge(Huge s1, Huge s2) {
  return( s1.key > s2.key);
}

void swapHuge(Huge* s1, Huge* s2) {
  Huge tmp = *s1;
  *s1 = *s2;
  *s2 = tmp;
}

void insertSortHuge(Huge *sa, unsigned int elems) {
  unsigned int j, k;

  for( k=1; k < elems; k++) {
    j = k;
    while( j > 0 && compareHuge( sa[j-1], sa[j] ) ) {
      swapHuge(&sa[j-1], &sa[j] ); j--;
    }
  }
}

int main() {
  Huge hugeArray[10];
  int ar[] = {17, 2, -3, 3, 4, 16, 1, 0, 23, 12, 1};

  for (int i = 0; i < 10; i++) {
    hugeArray[i].key = ar[i];
  }
  insertSortHuge(hugeArray, 10);
  for (int i = 0; i < 10; i++) {
    std::cout << hugeArray[i].key << std::endl;
  }
}
